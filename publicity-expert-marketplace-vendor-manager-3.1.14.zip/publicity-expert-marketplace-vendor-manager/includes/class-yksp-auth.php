<?php
if(!defined('ABSPATH')) exit;
class YKSP_Auth{
 public static function init(){
  add_action('wp_ajax_yksp_logout',array(__CLASS__,'logout'));
  add_action('wp_ajax_yksp_update_profile',array(__CLASS__,'update_profile'));
 }
 private static function nonce(){
  if(!check_ajax_referer('yksp_nonce','nonce',false)) wp_send_json_error(array('message'=>'Security check failed.'),403);
 }
 public static function is_seller($uid=0){
  $u=get_user_by('id',$uid?:get_current_user_id());
  return $u && in_array('yk_seller',(array)$u->roles,true);
 }
 public static function migrate_legacy_seller_statuses(){
  // Sellers created by older OTP-enabled releases could remain locked in otp_pending.
  // Convert only legacy seller accounts; never alter suspended or approved accounts.
  // phpcs:disable WordPress.DB.SlowDBQuery.slow_db_query_meta_key, WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- One-time migration query scoped to legacy seller accounts.
  $users=get_users(array(
   'role'=>'yk_seller',
   'meta_key'=>'yksp_status',
   'meta_value'=>'otp_pending',
   'fields'=>'ID',
   'number'=>-1
  ));
  // phpcs:enable WordPress.DB.SlowDBQuery.slow_db_query_meta_key, WordPress.DB.SlowDBQuery.slow_db_query_meta_value
  foreach($users as $uid){
   update_user_meta($uid,'yksp_status','pending');
   delete_user_meta($uid,'yksp_otp_hash');
   delete_user_meta($uid,'yksp_otp_expires');
   delete_user_meta($uid,'yksp_otp_attempts');
   delete_user_meta($uid,'yksp_otp_sent_at');
  }
  update_option('yksp_otp_migration_316',current_time('mysql'));
 }
 public static function status($uid=0){return get_user_meta($uid?:get_current_user_id(),'yksp_status',true)?:'pending';}
 public static function approved($uid=0){return self::status($uid)==='approved';}
 private static function check(){self::nonce();if(!is_user_logged_in()||!self::is_seller())wp_send_json_error(array('message'=>'Seller login required.'),403);}
 private static function client_key(){
  $ip=isset($_SERVER['REMOTE_ADDR'])?sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])):'';
  return substr(hash_hmac('sha256',$ip,wp_salt('auth')),0,24);
 }
 private static function rate_limit($action,$limit,$window,$email=''){
  $email_key=$email?sanitize_email($email):'';
  $key='yksp_rl_'.$action.'_'.substr(hash_hmac('sha256',self::client_key().'|'.$email_key,wp_salt('auth')),0,32);
  $count=(int)get_transient($key);
  if($count>=$limit)return false;
  set_transient($key,$count+1,$window);
  return true;
 }
 private static function clear_rate_limit($action,$email=''){
  $email_key=$email?sanitize_email($email):'';
  $key='yksp_rl_'.$action.'_'.substr(hash_hmac('sha256',self::client_key().'|'.$email_key,wp_salt('auth')),0,32);
  delete_transient($key);
 }
 public static function register_data($d){
  $name=sanitize_text_field($d['name']??'');$email=sanitize_email($d['email']??'');
  $phone=sanitize_text_field($d['phone']??'');$pass=(string)($d['password']??'');
  $business=sanitize_text_field($d['business']??'');$type=sanitize_text_field($d['business_type']??'');
  $gst=sanitize_text_field($d['gst']??'');$pan=sanitize_text_field($d['pan']??'');
  $address=sanitize_textarea_field($d['address']??'');$holder=sanitize_text_field($d['account_holder']??'');
  $bank=sanitize_text_field($d['bank']??'');$account=sanitize_text_field($d['account_number']??'');
  $ifsc=sanitize_text_field($d['ifsc']??'');$agree=!empty($d['agreement']);
  if(!$name||!is_email($email)||strlen($pass)<8||!$phone||!$business||!$address||!$agree)
   return new WP_Error('validation','Complete all required fields. Password must be at least 8 characters.',array('status'=>422));
  if(!self::rate_limit('register',5,HOUR_IN_SECONDS,$email))
   return new WP_Error('registration_rate_limited','Too many registration attempts. Please try again later.',array('status'=>429));
  if(email_exists($email)) return new WP_Error('email_exists','This email is already registered.',array('status'=>409));
  $username=sanitize_user(current(explode('@',$email)),true)?:'seller';
  if(username_exists($username)) $username.='-'.wp_rand(100,9999);
  $uid=wp_create_user($username,$pass,$email);
  if(is_wp_error($uid)) return new WP_Error('registration_failed',$uid->get_error_message(),array('status'=>422));
  $user=new WP_User($uid);
  $user->set_role('yk_seller');
  wp_update_user(array('ID'=>$uid,'display_name'=>$name,'first_name'=>$name));
  foreach(array(
   'yksp_phone'=>$phone,'yksp_business'=>$business,'yksp_business_type'=>$type,'yksp_gst'=>$gst,'yksp_pan'=>$pan,
   'yksp_address'=>$address,'yksp_account_holder'=>$holder,'yksp_bank'=>$bank,'yksp_account_number'=>$account,
   'yksp_ifsc'=>$ifsc,'yksp_status'=>'pending',
   'yksp_agreement_at'=>current_time('mysql')
  ) as $k=>$v) update_user_meta($uid,$k,$v);
  update_user_meta($uid,'yksp_status','pending');
  wp_mail(get_option('admin_email'),'New Marketplace Vendor Application',"New seller application: $name <$email>. Review under Marketplace Vendors.");
  return array('success'=>true,'otp_required'=>false,'message'=>'Registration submitted successfully. Your seller application is now pending YourKart approval.');
 }
 public static function register_fallback(){
  $method=isset($_SERVER['REQUEST_METHOD'])?sanitize_key(wp_unslash($_SERVER['REQUEST_METHOD'])):'';
  if($method!=='POST') wp_die(esc_html__('Invalid request.','publicity-expert-marketplace-vendor-manager'),'',array('response'=>405));
  if(!isset($_POST['yksp_register_nonce'])||!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['yksp_register_nonce'])),'yksp_register')) wp_die(esc_html__('Security check failed. Please try again.','publicity-expert-marketplace-vendor-manager'),'',array('response'=>403));
  $result=self::register_data(wp_unslash($_POST));
  $redirect=wp_get_referer()?:home_url('/');
  if(is_wp_error($result)){
   $redirect=add_query_arg(array('yksp_registration'=>'error','yksp_message'=>rawurlencode($result->get_error_message())),$redirect);
  } else {
   $redirect=add_query_arg(array('yksp_registration'=>'success'),$redirect);
  }
  wp_safe_redirect($redirect);exit;
 }
 public static function login_data($d){
  $email=sanitize_email($d['email']??'');
  $pass=(string)($d['password']??'');
  if(!$email||!$pass) return new WP_Error('login_failed','Enter your seller email and password.',array('status'=>422));
  if(!self::rate_limit('login',10,15*MINUTE_IN_SECONDS,$email))
   return new WP_Error('login_rate_limited','Too many login attempts. Please try again later.',array('status'=>429));

  $u=get_user_by('email',$email);
  if(!$u||!self::is_seller($u->ID))
   return new WP_Error('login_failed','Invalid email or password.',array('status'=>401));

  // Backward compatibility: old accounts may still carry otp_pending.
  if(self::status($u->ID)==='otp_pending'){
   update_user_meta($u->ID,'yksp_status','pending');
   delete_user_meta($u->ID,'yksp_otp_hash');
   delete_user_meta($u->ID,'yksp_otp_expires');
   delete_user_meta($u->ID,'yksp_otp_attempts');
   delete_user_meta($u->ID,'yksp_otp_sent_at');
  }

  $status=self::status($u->ID);
  if($status==='suspended')
   return new WP_Error('login_failed','Your seller account is suspended. Please contact the marketplace administrator.',array('status'=>403));

  // wp_signon creates a normal WordPress authentication session. WordPress permits
  // independent sessions on multiple browsers/devices unless another plugin blocks them.
  $signed=wp_signon(
   array('user_login'=>$u->user_login,'user_password'=>$pass,'remember'=>true),
   is_ssl()
  );
  if(is_wp_error($signed))
   return new WP_Error('login_failed','Invalid email or password.',array('status'=>401));
  self::clear_rate_limit('login',$email);

  // Explicitly refresh the current request's auth state so the same request and
  // subsequent REST/AJAX calls recognize the seller.
  wp_set_current_user($signed->ID);

  return array(
   'success'=>true,
   'message'=>'Login successful.',
   'status'=>self::status($signed->ID),
   'user'=>array('id'=>$signed->ID,'name'=>$signed->display_name,'email'=>$signed->user_email)
  );
 }
 public static function verify_otp(){
  // phpcs:ignore WordPress.Security.NonceVerification.Missing -- self::nonce() performs nonce verification before reading POST data.
  self::nonce();$input=wp_unslash($_POST);$email=sanitize_email($input['email']??'');$otp=preg_replace('/\D/','',(string)($input['otp']??''));
  $u=get_user_by('email',$email);
  if(!$u||!self::is_seller($u->ID))wp_send_json_error(array('message'=>'Seller account not found.'),404);
  if(self::status($u->ID)!=='otp_pending')wp_send_json_error(array('message'=>'This account does not require OTP verification.'));
  if(time()>(int)get_user_meta($u->ID,'yksp_otp_expires',true))wp_send_json_error(array('message'=>'OTP expired. Please request a new OTP.'),422);
  $attempts=(int)get_user_meta($u->ID,'yksp_otp_attempts',true);
  if($attempts>=5)wp_send_json_error(array('message'=>'Too many OTP attempts. Request a new OTP.'),429);
  update_user_meta($u->ID,'yksp_otp_attempts',$attempts+1);
  if(strlen($otp)!==6||!hash_equals((string)get_user_meta($u->ID,'yksp_otp_hash',true),hash_hmac('sha256',$otp,wp_salt('auth'))))wp_send_json_error(array('message'=>'Invalid OTP.'),422);
  update_user_meta($u->ID,'yksp_status','pending');
  delete_user_meta($u->ID,'yksp_otp_hash');delete_user_meta($u->ID,'yksp_otp_expires');delete_user_meta($u->ID,'yksp_otp_attempts');
  wp_mail(get_option('admin_email'),'Marketplace Vendor Email Verified','Seller '.$u->user_email.' has verified their email and is ready for review.');
  wp_send_json_success(array('message'=>'Email verified successfully. Your application is now pending YourKart approval.'));
 }
 public static function resend_otp(){
  // phpcs:ignore WordPress.Security.NonceVerification.Missing -- self::nonce() performs nonce verification before reading POST data.
  self::nonce();$input=wp_unslash($_POST);$email=sanitize_email($input['email']??'');$u=get_user_by('email',$email);
  if(!$u||!self::is_seller($u->ID))wp_send_json_error(array('message'=>'Seller account not found.'),404);
  if(self::status($u->ID)!=='otp_pending')wp_send_json_error(array('message'=>'OTP verification is not pending.'));
  $last=(int)get_user_meta($u->ID,'yksp_otp_sent_at',true);
  if($last&&time()-$last<60)wp_send_json_error(array('message'=>'Please wait 60 seconds before requesting another OTP.'),429);
  $otp=wp_rand(100000,999999);update_user_meta($u->ID,'yksp_otp_hash',hash_hmac('sha256',(string)$otp,wp_salt('auth')));
  update_user_meta($u->ID,'yksp_otp_expires',time()+((int)get_option('yksp_otp_expiry',10)*60));update_user_meta($u->ID,'yksp_otp_attempts',0);update_user_meta($u->ID,'yksp_otp_sent_at',time());
  wp_mail($email,'Marketplace Vendor Verification Code',"Your verification code is: $otp\n\nIt expires in ".(int)get_option('yksp_otp_expiry',10)." minutes.");
  wp_send_json_success(array('message'=>'A new OTP has been sent.'));
 }
 public static function logout(){self::nonce();wp_logout();wp_send_json_success(array('message'=>'Logged out.'));}
 public static function update_profile(){
  self::check();$uid=get_current_user_id();
  // phpcs:disable WordPress.Security.NonceVerification.Missing -- self::check() verifies the AJAX nonce before POST processing.
  // phpcs:ignore WordPress.Security.NonceVerification.Missing -- self::check() verifies the AJAX nonce and seller capability before POST processing.
  $name=sanitize_text_field(wp_unslash($_POST['name']??''));$phone=sanitize_text_field(wp_unslash($_POST['phone']??''));
  $business=sanitize_text_field(wp_unslash($_POST['business']??''));$address=sanitize_textarea_field(wp_unslash($_POST['address']??''));
  if(!$name||!$business)wp_send_json_error(array('message'=>'Name and business are required.'),422);
  wp_update_user(array('ID'=>$uid,'display_name'=>$name,'first_name'=>$name));
  foreach(array('yksp_phone'=>$phone,'yksp_business'=>$business,'yksp_address'=>$address) as $k=>$v)update_user_meta($uid,$k,$v);
  wp_send_json_success(array('message'=>'Profile updated successfully.'));
  // phpcs:enable WordPress.Security.NonceVerification.Missing
 }
}
