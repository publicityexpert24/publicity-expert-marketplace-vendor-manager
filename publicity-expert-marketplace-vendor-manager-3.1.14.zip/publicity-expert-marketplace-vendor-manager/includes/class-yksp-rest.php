<?php
if(!defined('ABSPATH')) exit;
class YKSP_REST{
 public static function init(){add_action('rest_api_init',array(__CLASS__,'routes'));}
 public static function routes(){
  register_rest_route('publicity-expert-marketplace-vendor-manager/v1','/register',array('methods'=>'POST','callback'=>array(__CLASS__,'register'),'permission_callback'=>'__return_true'));
  register_rest_route('publicity-expert-marketplace-vendor-manager/v1','/login',array('methods'=>'POST','callback'=>array(__CLASS__,'login'),'permission_callback'=>'__return_true'));
  register_rest_route('publicity-expert-marketplace-vendor-manager/v1','/verify-otp',array('methods'=>'POST','callback'=>array(__CLASS__,'otp_disabled'),'permission_callback'=>'__return_true'));
  register_rest_route('publicity-expert-marketplace-vendor-manager/v1','/resend-otp',array('methods'=>'POST','callback'=>array(__CLASS__,'otp_disabled'),'permission_callback'=>'__return_true'));
  register_rest_route('publicity-expert-marketplace-vendor-manager/v1','/me',array('methods'=>'GET','callback'=>array(__CLASS__,'me'),'permission_callback'=>array(__CLASS__,'seller')));
 }
 private static function params($r){$p=$r->get_json_params();return is_array($p)?$p:array();}
 private static function seller(){return is_user_logged_in()&&YKSP_Auth::is_seller();}
 public static function register($r){$x=YKSP_Auth::register_data(self::params($r));return is_wp_error($x)?$x:new WP_REST_Response($x,201);}
 public static function login($r){$x=YKSP_Auth::login_data(self::params($r));return is_wp_error($x)?$x:new WP_REST_Response($x,200);}
 public static function otp_disabled(){return new WP_Error('otp_disabled','Email OTP verification has been disabled.',array('status'=>410));}
 public static function me(){
  $u=wp_get_current_user();return array('id'=>$u->ID,'name'=>$u->display_name,'email'=>$u->user_email,'status'=>YKSP_Auth::status($u->ID),'business'=>get_user_meta($u->ID,'yksp_business',true));
 }
}
