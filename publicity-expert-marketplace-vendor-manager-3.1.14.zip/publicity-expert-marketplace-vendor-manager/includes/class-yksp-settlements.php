<?php
if(!defined('ABSPATH')) exit;
class YKSP_Settlements{
 public static function init(){add_action('wp_ajax_yksp_settlements',array(__CLASS__,'list_for_seller'));}
 public static function create_for_order($oid){
  $o=wc_get_order($oid);if(!$o)return;global $wpdb;$t=$wpdb->prefix.'yksp_settlements';$rate=(float)get_option('yksp_commission_rate',10);$totals=array();
  foreach($o->get_items() as $item){$p=$item->get_product();if(!$p)continue;$sid=(int)$p->get_meta('_yksp_seller_id');if($sid)$totals[$sid]=($totals[$sid]??0)+(float)$item->get_total();}
  foreach($totals as $sid=>$gross){
   // Custom plugin-owned table; %i safely quotes the table identifier.
  // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Required for plugin-owned settlement data.
   // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Required to check the plugin-owned settlement table for an existing record.
   if($wpdb->get_var($wpdb->prepare("SELECT id FROM %i WHERE order_id=%d AND seller_id=%d",$t,$oid,$sid)))continue;
   $comm=round($gross*$rate/100,2);
   // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Required to insert into the plugin-owned custom settlement table.
   $wpdb->insert($t,array('seller_id'=>$sid,'order_id'=>$oid,'gross_amount'=>$gross,'commission_amount'=>$comm,'seller_amount'=>$gross-$comm,'status'=>'pending','created_at'=>current_time('mysql')),array('%d','%d','%f','%f','%f','%s','%s'));
  }
 }
 public static function list_for_seller(){
  if(!check_ajax_referer('yksp_nonce','nonce',false))wp_send_json_error(array('message'=>'Security check failed.'),403);
  if(!is_user_logged_in()||!YKSP_Auth::is_seller())wp_send_json_error(array('message'=>'Seller login required.'),403);
  global $wpdb;$t=$wpdb->prefix.'yksp_settlements';
  // Custom plugin-owned table; %i safely quotes the table identifier.
  // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Required for plugin-owned settlement data.
  $rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM %i WHERE seller_id=%d ORDER BY id DESC LIMIT 100",$t,get_current_user_id()),ARRAY_A);
  $summary=array('gross'=>0,'commission'=>0,'seller'=>0,'paid'=>0,'pending'=>0);
  foreach($rows as &$r){$summary['gross']+=(float)$r['gross_amount'];$summary['commission']+=(float)$r['commission_amount'];$summary['seller']+=(float)$r['seller_amount'];if($r['status']==='paid')$summary['paid']+=(float)$r['seller_amount'];else $summary['pending']+=(float)$r['seller_amount'];}
  wp_send_json_success(array('settlements'=>$rows,'summary'=>$summary));
 }
}
