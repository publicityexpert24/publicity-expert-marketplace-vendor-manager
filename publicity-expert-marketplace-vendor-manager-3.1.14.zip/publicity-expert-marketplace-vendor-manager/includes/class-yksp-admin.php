<?php
if(!defined('ABSPATH')) exit;
class YKSP_Admin{
 public static function init(){
  add_action('admin_menu',array(__CLASS__,'menu'));
  add_action('admin_post_yksp_seller_status',array(__CLASS__,'seller_status'));
  add_action('admin_post_yksp_product_status',array(__CLASS__,'product_status'));
  add_action('admin_post_yksp_settle',array(__CLASS__,'settle'));
  add_action('admin_post_yksp_kyc_status',array(__CLASS__,'kyc_status'));
  add_action('admin_init',array(__CLASS__,'settings'));
 }
 private static function can(){return current_user_can('manage_woocommerce');}
 public static function menu(){
  add_menu_page('Marketplace Vendors','Marketplace Vendors','manage_woocommerce','yksp-sellers',array(__CLASS__,'sellers'),'dashicons-store',56);
  add_submenu_page('yksp-sellers','Seller Applications','Seller Applications','manage_woocommerce','yksp-sellers',array(__CLASS__,'sellers'));
  add_submenu_page('yksp-sellers','KYC Review','KYC Review','manage_woocommerce','yksp-kyc',array(__CLASS__,'kyc'));
  add_submenu_page('yksp-sellers','Product Approval','Product Approval','manage_woocommerce','yksp-products',array(__CLASS__,'products'));
  add_submenu_page('yksp-sellers','Settlements','Settlements','manage_woocommerce','yksp-settlements',array(__CLASS__,'settlements'));
  add_submenu_page('yksp-sellers','Settings','Settings','manage_woocommerce','yksp-settings',array(__CLASS__,'settings_page'));
 }
 public static function sellers(){
  if(!self::can())return;$users=get_users(array('role'=>'yk_seller','number'=>300));?>
  <div class="wrap"><h1>Marketplace Vendor Applications</h1><table class="widefat striped"><thead><tr><th>Seller</th><th>Business</th><th>Email</th><th>OTP</th><th>Status</th><th>Actions</th></tr></thead><tbody>
  <?php foreach($users as $u):$s=YKSP_Auth::status($u->ID);?><tr><td><?php echo esc_html($u->display_name);?></td><td><?php echo esc_html(get_user_meta($u->ID,'yksp_business',true));?></td><td><?php echo esc_html($u->user_email);?></td><td><?php echo esc_html($s==='otp_pending'?'Pending':'Verified');?></td><td><?php echo esc_html(ucfirst($s));?></td><td>
  <?php if($s!=='approved'):?><a class="button button-primary" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=yksp_seller_status&user_id='.$u->ID.'&status=approved'),'yksp_seller_status'));?>">Approve</a><?php endif;?>
  <?php if($s!=='suspended'):?><a class="button" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=yksp_seller_status&user_id='.$u->ID.'&status=suspended'),'yksp_seller_status'));?>">Suspend</a><?php endif;?>
  </td></tr><?php endforeach;?></tbody></table></div><?php
 }
 public static function kyc(){
  if(!self::can())return;$users=get_users(array('role'=>'yk_seller','number'=>300));?>
  <div class="wrap"><h1>Marketplace Vendor KYC Review</h1><table class="widefat striped"><thead><tr><th>Seller</th><th>PAN</th><th>GST</th><th>Bank</th><th>Address</th><th>Action</th></tr></thead><tbody>
  <?php foreach($users as $u):?><tr><td><?php echo esc_html($u->display_name);?></td>
  <?php foreach(array('pan_document','gst_document','bank_document','address_document') as $f):$path=get_user_meta($u->ID,'yksp_'.$f.'_file',true);?><td><?php if($path&&is_string($path)&&file_exists($path)):?><a href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=yksp_kyc_download&user_id='.$u->ID.'&field='.$f),'yksp_kyc_download_'.$u->ID.'_'.$f));?>" target="_blank" rel="noopener">View</a> — <?php echo esc_html(get_user_meta($u->ID,'yksp_'.$f.'_status',true)?:'submitted');?><?php else:?>Missing<?php endif;?></td><?php endforeach;?>
  <td><?php if(YKSP_Auth::status($u->ID)!=='approved'):?><a class="button button-primary" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=yksp_seller_status&user_id='.$u->ID.'&status=approved'),'yksp_seller_status'));?>">Approve Seller</a><?php endif;?></td></tr><?php endforeach;?></tbody></table></div><?php
 }
 public static function products(){
  if(!self::can())return;
  // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- Admin-only product approval list is intentionally filtered by the plugin's seller meta key.
  $products=get_posts(array('post_type'=>'product','post_status'=>array('pending','draft'),'numberposts'=>300,'meta_key'=>'_yksp_seller_id'));?>
  <div class="wrap"><h1>Marketplace Vendor Product Approval</h1><table class="widefat striped"><thead><tr><th>Product</th><th>Seller</th><th>SKU</th><th>Status</th><th>Actions</th></tr></thead><tbody>
  <?php foreach($products as $p):$sid=(int)get_post_meta($p->ID,'_yksp_seller_id',true);$u=get_user_by('id',$sid);?><tr><td><?php echo esc_html($p->post_title);?></td><td><?php echo esc_html($u?$u->display_name:'Unknown');?></td><td><?php echo esc_html(get_post_meta($p->ID,'_sku',true));?></td><td><?php echo esc_html($p->post_status);?></td><td>
  <a class="button button-primary" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=yksp_product_status&product_id='.$p->ID.'&status=publish'),'yksp_product_status'));?>">Approve & Publish</a>
  <a class="button" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=yksp_product_status&product_id='.$p->ID.'&status=draft'),'yksp_product_status'));?>">Reject</a></td></tr><?php endforeach;?></tbody></table></div><?php
 }
 public static function seller_status(){
  if(!self::can())wp_die('Unauthorized');check_admin_referer('yksp_seller_status');$uid=absint($_GET['user_id']??0);$s=sanitize_key($_GET['status']??'pending');
  if($uid&&in_array($s,array('approved','pending','suspended'),true)){update_user_meta($uid,'yksp_status',$s);$u=get_user_by('id',$uid);if($u&&$s==='approved')wp_mail($u->user_email,'Your Marketplace Vendor Account is Approved','Your vendor account has been approved. You can now log in and submit products.');}
  wp_safe_redirect(admin_url('admin.php?page=yksp-sellers'));exit;
 }
 public static function product_status(){
  if(!self::can())wp_die('Unauthorized');check_admin_referer('yksp_product_status');$pid=absint($_GET['product_id']??0);$s=sanitize_key($_GET['status']??'draft');
  if($pid&&in_array($s,array('publish','draft'),true))wp_update_post(array('ID'=>$pid,'post_status'=>$s));
  wp_safe_redirect(admin_url('admin.php?page=yksp-products'));exit;
 }
 public static function kyc_status(){
  if(!self::can())wp_die('Unauthorized');check_admin_referer('yksp_kyc_status');$uid=absint($_GET['user_id']??0);$field=sanitize_key($_GET['field']??'');$s=sanitize_key($_GET['status']??'');
  if($uid&&in_array($field,array('pan_document','gst_document','bank_document','address_document'),true)&&in_array($s,array('approved','rejected'),true))update_user_meta($uid,'yksp_'.$field.'_status',$s);
  wp_safe_redirect(admin_url('admin.php?page=yksp-kyc'));exit;
 }
 public static function settings(){
  register_setting('yksp_settings','yksp_commission_rate',array('type'=>'number','sanitize_callback'=>function($v){return min(100,max(0,(float)$v));},'default'=>10));
 }
 public static function settings_page(){
  if(!self::can())return;?>
  <div class="wrap"><h1>Marketplace Vendor Settings</h1><form method="post" action="options.php"><?php settings_fields('yksp_settings');?>
  <table class="form-table"><tr><th>Default Commission %</th><td><input type="number" step=".01" min="0" max="100" name="yksp_commission_rate" value="<?php echo esc_attr(get_option('yksp_commission_rate',10));?>"></td></tr>
</table><?php submit_button();?></form></div><?php
 }
 public static function settlements(){
  if(!self::can())return;global $wpdb;$t=$wpdb->prefix.'yksp_settlements';
  // Custom plugin-owned table; %i safely quotes the table identifier.
  // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Required for plugin-owned settlement data.
  // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Required to read the plugin-owned settlements table.
  $rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM %i ORDER BY id DESC LIMIT 500",$t));?>
  <div class="wrap"><h1>Marketplace Vendor Settlements</h1><table class="widefat striped"><thead><tr><th>ID</th><th>Seller</th><th>Order</th><th>Gross</th><th>Commission</th><th>Seller Amount</th><th>Status</th><th>Action</th></tr></thead><tbody>
  <?php foreach($rows as $r):$u=get_user_by('id',$r->seller_id);?><tr><td><?php echo esc_html($r->id);?></td><td><?php echo esc_html($u?$u->display_name:'Unknown');?></td><td>#<?php echo esc_html($r->order_id);?></td><td><?php echo wp_kses_post(wc_price($r->gross_amount));?></td><td><?php echo wp_kses_post(wc_price($r->commission_amount));?></td><td><?php echo wp_kses_post(wc_price($r->seller_amount));?></td><td><?php echo esc_html($r->status);?></td><td><?php if($r->status==='pending'):?><a class="button" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=yksp_settle&id='.$r->id),'yksp_settle'));?>">Mark Paid</a><?php endif;?></td></tr><?php endforeach;?></tbody></table></div><?php
 }
 public static function settle(){
  if(!self::can())wp_die('Unauthorized');check_admin_referer('yksp_settle');global $wpdb;$t=$wpdb->prefix.'yksp_settlements';$id=absint($_GET['id']??0);
  if($id){
   // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Required to update plugin-owned settlement records.
   $wpdb->update($t,array('status'=>'paid','paid_at'=>current_time('mysql')),array('id'=>$id),array('%s','%s'),array('%d'));
  }
  wp_safe_redirect(admin_url('admin.php?page=yksp-settlements'));exit;
 }
}
