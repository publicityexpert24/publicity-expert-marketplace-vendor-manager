<?php
if(!defined('ABSPATH')) exit;
class YKSP_Products{
 public static function init(){
  add_action('wp_ajax_yksp_product_save',array(__CLASS__,'save'));
  add_action('wp_ajax_yksp_product_delete',array(__CLASS__,'delete'));
  add_action('wp_ajax_yksp_product_list',array(__CLASS__,'list_products'));
  add_action('wp_ajax_yksp_product_get',array(__CLASS__,'get_product'));
 }
 private static function check(){
  if(!check_ajax_referer('yksp_nonce','nonce',false))wp_send_json_error(array('message'=>'Security check failed.'),403);
  if(!is_user_logged_in()||!YKSP_Auth::is_seller())wp_send_json_error(array('message'=>'Seller login required.'),403);
 }
 private static function approved(){if(!YKSP_Auth::approved())wp_send_json_error(array('message'=>'Your seller account must be approved before you can submit products.'),403);}
 private static function owned($id){$p=wc_get_product($id);return $p&&(int)$p->get_meta('_yksp_seller_id')===get_current_user_id();}
 private static function category($cat){
  $term=get_term_by('name',$cat,'product_cat');
  if(!$term){$n=wp_insert_term($cat,'product_cat');$term=!is_wp_error($n)?get_term($n['term_id'],'product_cat'):false;}
  return $term;
 }
 public static function save(){
  self::check();check_ajax_referer('yksp_nonce','nonce');self::approved();
  $input=wp_unslash($_POST);$id=absint($input['product_id']??0);
  if($id&&!self::owned($id))wp_send_json_error(array('message'=>'Unauthorized product.'),403);
  $name=sanitize_text_field($input['name']??'');$cat=sanitize_text_field($input['category']??'');
  $sku=sanitize_text_field($input['sku']??'');$price=wc_format_decimal($input['price']??'');
  $mrp=wc_format_decimal($input['mrp']??'');$stock=max(0,absint($input['stock']??0));$brand=sanitize_text_field($input['brand']??'');
  $desc=wp_kses_post($input['description']??'');
  if(!$name||!$cat||$sku===''||$price==='')wp_send_json_error(array('message'=>'Product name, category, SKU and selling price are required.'),422);
  $existing=wc_get_product_id_by_sku($sku);
  if($existing&&$existing!==$id)wp_send_json_error(array('message'=>'This SKU is already in use.'),409);
  $p=$id?wc_get_product($id):new WC_Product_Simple();
  try{
   $p->set_name($name);$p->set_description($desc);$p->set_regular_price($mrp!==''?$mrp:$price);$p->set_sale_price($mrp!==''?$price:'');
   $p->set_sku($sku);$p->set_manage_stock(true);$p->set_stock_quantity($stock);$p->set_stock_status($stock?'instock':'outofstock');
   $p->set_status('pending');$p->update_meta_data('_yksp_seller_id',get_current_user_id());$p->update_meta_data('_yksp_brand',$brand);
   $term=self::category($cat);if($term)$p->set_category_ids(array($term->term_id));
   $pid=$p->save();
  }catch(Exception $e){wp_send_json_error(array('message'=>$e->getMessage()),422);}
  if(!$pid)wp_send_json_error(array('message'=>'Product could not be saved.'),422);
  // The WordPress upload API requires the raw PHP upload array; validation is performed by media_handle_upload().
  // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Required raw upload data for WordPress media API.
  if(!empty($_FILES['product_image']['name'])){
   require_once ABSPATH.'wp-admin/includes/file.php';require_once ABSPATH.'wp-admin/includes/media.php';require_once ABSPATH.'wp-admin/includes/image.php';
   $aid=media_handle_upload('product_image',0);
   if(!is_wp_error($aid)){$p=wc_get_product($pid);$p->set_image_id($aid);$p->save();}
  }
  wp_send_json_success(array('message'=>$id?'Product updated and resubmitted for approval.':'Product added and submitted for approval.','product_id'=>$pid));
 }
 public static function get_product(){
  self::check();check_ajax_referer('yksp_nonce','nonce');$input=wp_unslash($_POST);$id=absint($input['product_id']??0);if(!$id||!self::owned($id))wp_send_json_error(array('message'=>'Unauthorized.'),403);
  $p=wc_get_product($id);$terms=wp_get_post_terms($id,'product_cat',array('fields'=>'names'));
  wp_send_json_success(array('product'=>array(
   'id'=>$id,'name'=>$p->get_name(),'sku'=>$p->get_sku(),'category'=>implode(', ',$terms),'price'=>$p->get_sale_price()?:$p->get_regular_price(),
   'mrp'=>$p->get_regular_price(),'stock'=>$p->get_stock_quantity(),'brand'=>$p->get_meta('_yksp_brand'),'description'=>$p->get_description(),
   'image'=>$p->get_image_id()?wp_get_attachment_url($p->get_image_id()):''
  )));
 }
 public static function delete(){
  // phpcs:ignore WordPress.Security.NonceVerification.Missing -- self::check() verifies the AJAX nonce and seller capability before POST processing.
  self::check();check_ajax_referer('yksp_nonce','nonce');$input=wp_unslash($_POST);$id=absint($input['product_id']??0);if(!$id||!self::owned($id))wp_send_json_error(array('message'=>'Unauthorized.'),403);
  $p=wc_get_product($id);if($p)$p->delete(true);wp_send_json_success(array('message'=>'Product deleted.'));
 }
 public static function list_products(){
  // phpcs:ignore WordPress.Security.NonceVerification.Missing -- self::check() verifies the AJAX nonce and seller capability before processing the request.
  self::check();
  // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key, WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- Seller product list intentionally filters by the plugin-owned seller meta fields.
  check_ajax_referer('yksp_nonce','nonce');
  $ids=get_posts(array('post_type'=>'product','post_status'=>array('publish','pending','draft','private'),'numberposts'=>-1,'fields'=>'ids','meta_key'=>'_yksp_seller_id','meta_value'=>get_current_user_id()));
  $out=array();
  foreach($ids as $id){$p=wc_get_product($id);if(!$p)continue;$terms=wp_get_post_terms($id,'product_cat',array('fields'=>'names'));$out[]=array(
   'id'=>$id,'name'=>$p->get_name(),'sku'=>$p->get_sku(),'price'=>$p->get_price(),'stock'=>$p->get_stock_quantity(),'status'=>$p->get_status(),
   'category'=>implode(', ',$terms),'image'=>$p->get_image_id()?wp_get_attachment_url($p->get_image_id()):''
  );}
  wp_send_json_success(array('products'=>$out));
 }
}
