<?php
if(!defined('ABSPATH')) exit;
class YKSP_Returns{
 public static function init(){add_action('wp_ajax_yksp_returns',array(__CLASS__,'returns'));add_action('wp_ajax_yksp_return_action',array(__CLASS__,'action'));}
 private static function check(){
  if(!check_ajax_referer('yksp_nonce','nonce',false))wp_send_json_error(array('message'=>'Security check failed.'),403);
  if(!is_user_logged_in()||!YKSP_Auth::is_seller())wp_send_json_error(array('message'=>'Seller login required.'),403);
 }
 private static function seller_order($oid){
  $o=wc_get_order($oid);if(!$o)return false;
  foreach($o->get_items() as $item){$p=$item->get_product();if($p&&(int)$p->get_meta('_yksp_seller_id')===get_current_user_id())return $o;}
  return false;
 }
 public static function returns(){
  self::check();$sid=get_current_user_id();$ids=wc_get_orders(array('limit'=>100,'return'=>'ids','orderby'=>'date','order'=>'DESC'));$out=array();
  foreach($ids as $oid){$o=wc_get_order($oid);if(!$o)continue;
   foreach($o->get_refunds() as $refund){$amount=abs((float)$refund->get_amount());if(!$amount)continue;
    $seller_total=0;foreach($o->get_items() as $item){$p=$item->get_product();if($p&&(int)$p->get_meta('_yksp_seller_id')===$sid)$seller_total+=(float)$item->get_total();}
    if(!$seller_total)continue;
    $status=get_post_meta($refund->get_id(),'_yksp_return_status',true)?:'refund_recorded';
    $out[]=array('refund_id'=>$refund->get_id(),'order_id'=>$oid,'date'=>$refund->get_date_created()?$refund->get_date_created()->date_i18n(get_option('date_format')):'','amount'=>wc_price($amount),'status'=>$status);
   }
  }
  wp_send_json_success(array('returns'=>$out));
 }
 public static function action(){
  self::check();check_ajax_referer('yksp_nonce','nonce');$input=wp_unslash($_POST);$rid=absint($input['refund_id']??0);$status=sanitize_key($input['status']??'');
  if(!$rid||!in_array($status,array('received','inspected','approved','rejected'),true))wp_send_json_error(array('message'=>'Invalid return action.'),422);
  $refund=wc_get_order($rid);if(!$refund||$refund->get_type()!=='shop_order_refund')wp_send_json_error(array('message'=>'Return record not found.'),404);
  $parent=$refund->get_parent_id();if(!self::seller_order($parent))wp_send_json_error(array('message'=>'Unauthorized return.'),403);
  update_post_meta($rid,'_yksp_return_status',$status);
  wp_send_json_success(array('message'=>'Return status updated to '.ucfirst($status).'.'));
 }
}
