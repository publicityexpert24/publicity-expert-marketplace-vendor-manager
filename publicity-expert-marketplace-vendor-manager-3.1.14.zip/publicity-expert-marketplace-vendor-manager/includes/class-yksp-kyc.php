<?php
if(!defined('ABSPATH')) exit;
class YKSP_KYC{
 public static function init(){
  add_action('wp_ajax_yksp_kyc_upload',array(__CLASS__,'upload'));
  add_action('wp_ajax_yksp_kyc_status',array(__CLASS__,'status_ajax'));
  add_action('admin_post_yksp_kyc_download',array(__CLASS__,'download'));
 }
 private static function check(){
  if(!check_ajax_referer('yksp_nonce','nonce',false))wp_send_json_error(array('message'=>'Security check failed.'),403);
  if(!is_user_logged_in()||!YKSP_Auth::is_seller())wp_send_json_error(array('message'=>'Vendor login required.'),403);
 }
 private static function allowed($field){return in_array($field,array('pan_document','gst_document','bank_document','address_document'),true);}
 private static function dir(){
  $uploads=wp_upload_dir();
  return trailingslashit($uploads['basedir']).'marketplace-vendor-manager-private';
 }
 private static function protect_dir(){
  $dir=self::dir();
  if(!wp_mkdir_p($dir))return false;
  $index=$dir.'/index.php'; if(!file_exists($index))@file_put_contents($index,"<?php\n// Silence is golden.\n");
  $htaccess=$dir.'/.htaccess'; if(!file_exists($htaccess))@file_put_contents($htaccess,"Options -Indexes\n<FilesMatch \".*\">\nRequire all denied\n</FilesMatch>\n");
  return true;
 }
 private static function mime($file){
  $type=wp_check_filetype_and_ext($file['tmp_name'],$file['name']);
  return !empty($type['type'])?$type['type']:'';
 }
 private static function private_upload_dir($uploads){
  $dir=self::dir();
  $uploads['path']=$dir;
  $uploads['url']='';
  $uploads['subdir']='';
  $uploads['basedir']=$dir;
  $uploads['baseurl']='';
  return $uploads;
 }
 public static function upload(){
  self::check();check_ajax_referer('yksp_nonce','nonce');$uid=get_current_user_id();$input=wp_unslash($_POST);$field=sanitize_key($input['document_type']??'');
  // PHP provides uploads through $_FILES; wp_handle_upload() requires this raw upload array.
  // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- The upload API validates the file; document type and size/MIME are validated below.
  $files=isset($_FILES['kyc_file'])?$_FILES['kyc_file']:array();
  if(!self::allowed($field)||empty($files['name']))wp_send_json_error(array('message'=>'Select a valid KYC document.'),422);
  $f=$files;
  if(!empty($f['error']))wp_send_json_error(array('message'=>'The upload could not be completed.'),422);
  if((int)$f['size']>8*1024*1024)wp_send_json_error(array('message'=>'Maximum file size is 8 MB.'),422);
  $mime=self::mime($f);
  $allowed=array('image/jpeg','image/png','application/pdf');
  if(!in_array($mime,$allowed,true))wp_send_json_error(array('message'=>'Only JPG, PNG or PDF files are allowed.'),422);
  if(!self::protect_dir())wp_send_json_error(array('message'=>'The secure upload directory could not be created.'),500);
  $old=get_user_meta($uid,'yksp_'.$field.'_file',true);
  if($old&&is_string($old)&&file_exists($old))wp_delete_file($old);
  require_once ABSPATH.'wp-admin/includes/file.php';
  add_filter('upload_dir',array(__CLASS__,'private_upload_dir'));
  $upload=wp_handle_upload($f,array(
   'test_form'=>false,
   'mimes'=>array('jpg|jpeg'=>'image/jpeg','png'=>'image/png','pdf'=>'application/pdf'),
   'unique_filename_callback'=>function($dir,$name,$ext)use($field,$uid){
    return sanitize_file_name($field.'-'.$uid.'-'.wp_generate_uuid4().$ext);
   }
  ));
  remove_filter('upload_dir',array(__CLASS__,'private_upload_dir'));
  if(isset($upload['error']))wp_send_json_error(array('message'=>'The document could not be stored securely.'),500);
  $target=!empty($upload['file'])?$upload['file']:'';
  if(!$target||!file_exists($target))wp_send_json_error(array('message'=>'The document could not be stored securely.'),500);
  update_user_meta($uid,'yksp_'.$field.'_file',$target);
  update_user_meta($uid,'yksp_'.$field.'_status','submitted');
  wp_send_json_success(array('message'=>'Document uploaded successfully.'));
 }
 public static function status_ajax(){
  self::check();$uid=get_current_user_id();$out=array();
  foreach(array('pan_document','gst_document','bank_document','address_document') as $f){
   $path=get_user_meta($uid,'yksp_'.$f.'_file',true);
   $out[$f]=array('uploaded'=>(bool)($path&&file_exists($path)),'status'=>get_user_meta($uid,'yksp_'.$f.'_status',true)?:'missing');
  }
  wp_send_json_success(array('documents'=>$out));
 }
 public static function download(){
  if(!current_user_can('manage_woocommerce'))wp_die('Unauthorized',403);
  $uid=absint($_GET['user_id']??0);$field=sanitize_key($_GET['field']??'');
  if(!$uid||!self::allowed($field))wp_die('Invalid document.',400);
  check_admin_referer('yksp_kyc_download_'.$uid.'_'.$field);
  $path=get_user_meta($uid,'yksp_'.$field.'_file',true);
  if(!$path||!is_string($path)||!file_exists($path))wp_die('Document not found.',404);
  $real=realpath($path);$base=realpath(self::dir());
  if(!$real||!$base||strpos($real,$base.DIRECTORY_SEPARATOR)!==0)wp_die('Invalid document path.',403);
  $mime=function_exists('mime_content_type')?mime_content_type($real):'application/octet-stream';
  $allowed=array('image/jpeg','image/png','application/pdf');
  if(!in_array($mime,$allowed,true))$mime='application/octet-stream';
  nocache_headers();header('Content-Type: '.$mime);header('Content-Disposition: inline; filename="'.basename($real).'"');
  require_once ABSPATH.'wp-admin/includes/file.php';
  global $wp_filesystem;
  if(!$wp_filesystem && !WP_Filesystem())wp_die('Unable to access document.',500);
  $size=$wp_filesystem->size($real);
  if(false!==$size)header('Content-Length: '.(int)$size);
  $content=$wp_filesystem->get_contents($real);
  if(false===$content)wp_die('Unable to read document.',500);
  // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- KYC document content is binary data and must be sent unchanged with the validated Content-Type header.
  echo $content;exit;
 }
}
