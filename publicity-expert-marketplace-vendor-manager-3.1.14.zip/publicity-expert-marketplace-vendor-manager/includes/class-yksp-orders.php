<?php
if(!defined('ABSPATH')) exit;
class YKSP_Orders{
 public static function init(){add_action('wp_ajax_yksp_orders',array(__CLASS__,'orders'));add_action('woocommerce_order_status_processing',array(__CLASS__,'settle'));add_action('woocommerce_order_status_completed',array(__CLASS__,'settle'));}
 private static function check(){
  if(!check_ajax_referer('yksp_nonce','nonce',false))wp_send_json_error(array('message'=>'Security check failed.'),403);
  if(!is_user_logged_in()||!YKSP_Auth::is_seller())wp_send_json_error(array('message'=>'Seller login required.'),403);
 }
 private static function seller_items($o,$sid){
  $items=array();$gross=0;
  foreach($o->get_items() as $item_id=>$item){
   $p=$item->get_product();if(!$p||(int)$p->get_meta('_yksp_seller_id')!==$sid)continue;
   $line=(float)$item->get_total();$gross+=$line;
   $items[]=array('item_id'=>$item_id,'product_id'=>$p->get_id(),'name'=>$p->get_name(),'qty'=>$item->get_quantity(),'total'=>$line,'sku'=>$p->get_sku());
  }
  return array($items,$gross);
 }
 public static function orders(){
  self::check();$sid=get_current_user_id();$ids=wc_get_orders(array('limit'=>100,'return'=>'ids','orderby'=>'date','order'=>'DESC','status'=>array_keys(wc_get_order_statuses())));$out=array();
  foreach($ids as $oid){$o=wc_get_order($oid);if(!$o)continue;list($items,$gross)=self::seller_items($o,$sid);if(!$gross)continue;
   $out[]=array('id'=>$oid,'date'=>$o->get_date_created()?$o->get_date_created()->date_i18n(get_option('date_format')):'',
    'customer'=>trim($o->get_billing_first_name().' '.$o->get_billing_last_name()),'amount'=>wc_price($gross),'status'=>wc_get_order_status_name($o->get_status()),
    'payment'=>$o->get_payment_method_title(),'items'=>$items,'shipping'=>$o->get_shipping_address_1().' '.$o->get_shipping_city().' '.$o->get_shipping_postcode());
  }
  wp_send_json_success(array('orders'=>$out));
 }
 public static function settle($oid){YKSP_Settlements::create_for_order($oid);}
}
