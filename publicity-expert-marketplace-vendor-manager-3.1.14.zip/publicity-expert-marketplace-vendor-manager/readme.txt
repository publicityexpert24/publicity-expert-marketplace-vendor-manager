=== Publicity Expert Marketplace Vendor Manager ===
Contributors: publicityexpert
Tags: multivendor, marketplace, vendors, sellers, woocommerce
Requires at least: 6.2
Requires PHP: 7.4
Requires Plugins: woocommerce
Tested up to: 7.1
Stable tag: 3.1.14
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Free multivendor marketplace management for WooCommerce with vendor registration, products, orders, returns and settlements.

== Description ==

Publicity Expert Marketplace Vendor Manager adds a vendor management layer to WooCommerce. Store administrators can review vendor applications, manage vendor approval, review KYC submissions, approve vendor products, and track marketplace settlements. Vendors receive a front-end portal for registration, profile management, KYC submission, product management, orders, returns and settlement information.

The plugin is designed to work with WooCommerce and does not require an external service for its core functionality.

== Features ==

* Vendor registration and approval workflow
* Front-end vendor login and dashboard
* Vendor product submission and editing
* Vendor ownership checks for product actions
* Vendor order and return views
* Commission and settlement tracking
* Administrator KYC review workflow
* Vendor status management
* WooCommerce integration
* Concurrent vendor sessions using normal WordPress authentication

== Installation ==

1. Install and activate WooCommerce.
2. Upload and activate Publicity Expert Marketplace Vendor Manager from Plugins > Add New > Upload Plugin.
3. Add the shortcode `[marketplace_vendor_manager]` to the page where the vendor portal should appear.
4. Keep the vendor application page accessible to prospective vendors.
5. Configure the default commission percentage under Marketplace Vendors > Settings.

The legacy shortcode `[yourkart_seller_portal]` remains supported for existing installations.

== Frequently Asked Questions ==

= Does this plugin require WooCommerce? =
Yes. WooCommerce is required for vendor products, orders and settlement functionality.

= Does the plugin require an external marketplace service? =
No. Core marketplace vendor management runs on the WordPress/WooCommerce site.

= Can vendors log in on multiple devices? =
Yes. Vendor authentication uses normal WordPress login sessions. A separate session-management plugin may impose its own restrictions.

= What file types are accepted for KYC documents? =
JPG, PNG and PDF files up to 8 MB per document are accepted.

== Privacy ==

The plugin stores vendor account, business, banking and KYC information entered by the site user. Site administrators are responsible for providing appropriate privacy notices, retention policies and access controls for their marketplace. KYC files are stored in a plugin-managed protected upload directory and are not exposed through the public vendor dashboard.

The plugin does not intentionally send vendor information to a third-party service as part of its core functionality. WordPress email functionality may be used for administrator/vendor notifications.

== Screenshots ==

1. Vendor registration and login
2. Vendor dashboard
3. Vendor product management
4. Vendor KYC upload
5. Administrator vendor applications
6. Administrator KYC review
7. Product approval
8. Settlement management

== Source Code ==

The maintained source code for this plugin is publicly available at:
https://github.com/publicityexpert24/publicity-expert-marketplace-vendor-manager

The repository includes the plugin source and the human-readable JavaScript source used for the seller portal asset.

== Development ==

The deployed JavaScript is maintained alongside its readable source in `assets/js/seller-portal-source.js`. No external build step is required to use the plugin.

== Changelog ==

= 3.1.14 =
* Hardened vendor registration and login with WordPress authentication and rate limiting.
* Removed the `upload_files` capability from vendor accounts.
* Vendor product and KYC uploads continue to use the plugin's validated upload APIs.
* Fixed the seller product-list request flow.

= 3.1.13 =
* Updated the public plugin name and identifiers for WordPress.org review.
* Documented the public source repository and readable seller portal JavaScript source.


= 3.1.9 =
* Updated protected KYC uploads to use the WordPress upload API and WordPress filesystem APIs.
* Removed direct file deletion/permission operations from KYC handling.
* Updated compatibility metadata for WordPress 7.1.

= 3.1.7 =
* Renamed the public plugin to Publicity Expert Marketplace Vendor Manager.
* Added the official WordPress.org-style readme.txt.
* Added GPLv2-or-later plugin metadata.
* Added a secure nonce-protected registration fallback handler.
* Added the Publicity Expert Marketplace Vendor Manager shortcode while retaining the legacy shortcode.
* Improved KYC document handling so documents are not exposed as public Media Library attachments.
* Updated public-facing branding and documentation.

= 3.1.6 =
* Existing seller login and legacy OTP status migration improvements.
* New registrations go directly to pending approval.
