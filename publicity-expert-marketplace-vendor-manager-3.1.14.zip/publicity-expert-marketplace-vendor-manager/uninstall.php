<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

global $wpdb;
$yksp_table = $wpdb->prefix . 'yksp_settlements';
// This is the plugin-owned custom table and must be removed on uninstall.
// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange -- Required to remove this plugin-owned custom table during uninstall.
$wpdb->query( $wpdb->prepare( 'DROP TABLE IF EXISTS %i', $yksp_table ) );

$yksp_options = array( 'yksp_commission_rate', 'yksp_otp_expiry', 'yksp_require_otp', 'yksp_version', 'yksp_otp_migration_316' );
foreach ( $yksp_options as $yksp_option ) {
    delete_option( $yksp_option );
}

$yksp_meta_keys = array( 'yksp_pan_document_file', 'yksp_gst_document_file', 'yksp_bank_document_file', 'yksp_address_document_file' );
$yksp_users = get_users( array( 'fields' => 'ID', 'number' => -1 ) );
foreach ( $yksp_users as $yksp_uid ) {
    foreach ( $yksp_meta_keys as $yksp_key ) {
        $yksp_path = get_user_meta( $yksp_uid, $yksp_key, true );
        if ( is_string( $yksp_path ) && $yksp_path && file_exists( $yksp_path ) ) {
            wp_delete_file( $yksp_path );
        }
        delete_user_meta( $yksp_uid, $yksp_key );
    }
}
