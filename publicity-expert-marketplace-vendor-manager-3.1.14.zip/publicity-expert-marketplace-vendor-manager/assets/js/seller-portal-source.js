/**
 * Publicity Expert Marketplace Vendor Manager
 * Human-readable source for assets/js/seller-portal.js.
 * This file is the maintained source for the deployed seller portal script.
 * No external build step is required.
 */

jQuery(function($){
const post=(a,d={})=>{d.action=a;d.nonce=YKSP.nonce;return $.ajax({url:YKSP.ajaxUrl,method:'POST',data:d});};
const formPost=(a,f)=>{let d=new FormData(f);d.append('action',a);d.append('nonce',YKSP.nonce);return $.ajax({url:YKSP.ajaxUrl,method:'POST',data:d,processData:false,contentType:false});};
const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
function showPanel(id){$('.yksp-auth-panel').removeClass('active');$('#yksp-'+id).addClass('active');}
$('.yksp-tab').on('click',function(){$('.yksp-tab').removeClass('active');$(this).addClass('active');showPanel($(this).data('tab'));});
$('[data-next],[data-prev]').on('click',function(){let n=$(this).data('next')||$(this).data('prev');$('.yksp-reg-step').removeClass('active');$('.yksp-reg-step[data-step="'+n+'"]').addClass('active');$('.yksp-progress span').each(function(i){$(this).toggleClass('active',i<n);});});
function restPost(route,obj){return $.ajax({url:YKSP.restUrl+route,method:'POST',contentType:'application/json',data:JSON.stringify(obj),dataType:'json'});}

$('#yksp-login-form').on('submit',function(e){
 e.preventDefault();
 let f=this,m=$(f).find('.yksp-message'),btn=$(f).find('button[type="submit"]');
 let email=$(f).find('[name="email"]').val().trim(),password=$(f).find('[name="password"]').val();
 if(!email||!password){m.text('Enter your seller email and password.');return;}
 btn.prop('disabled',true).text('Logging in…');m.text('');
 restPost('login',{email:email,password:password})
 .done(r=>{
   m.text(r.message||'Login successful.');
   setTimeout(()=>location.reload(),250);
 })
 .fail(x=>{
   let msg=x.responseJSON?.message||x.responseJSON?.data?.message||'Login failed. Please check your email and password.';
   m.text(msg);
 })
 .always(()=>btn.prop('disabled',false).text('Login'));
});
$('#yksp-registration-form').on('submit',function(e){
 e.preventDefault();let f=this,m=$(f).find('.yksp-message'),obj={};$(f).serializeArray().forEach(x=>obj[x.name]=x.value);
 if(!obj.agreement){m.text('Please accept the Seller Agreement.');return;}
 if(!obj.name||!obj.email||!obj.phone||!obj.password||obj.password.length<8||!obj.business||!obj.address){m.text('Please complete all required fields.');return;}
 m.text('Creating seller account…');
 restPost('register',obj).done(r=>{m.text(r.message||'Registration submitted.');if(r.success){f.reset();}})
 .fail(x=>{
   let msg=x.responseJSON?.message||'';
   if(!msg){
     m.text('REST API is unavailable. Using secure backup registration…');
     $('<input>',{type:'hidden',name:'action',value:'yksp_register_fallback'}).appendTo(f);
     f.attr('action',YKSP.fallbackRegisterUrl);
     f.removeAttribute ? f.removeAttribute('novalidate') : f.removeAttr('novalidate');
     HTMLFormElement.prototype.submit.call(f);
     return;
   }
   m.text(msg);
 });
});


function panel(n){$('.yksp-panel').removeClass('active');$('.yksp-sidebar button').removeClass('active');$('#yksp-panel-'+n).addClass('active');$('.yksp-sidebar button[data-panel="'+n+'"]').addClass('active');
 if(n==='products'||n==='overview')products();if(n==='orders')orders();if(n==='returns')returns();if(n==='settlements')settlements();if(n==='kyc')kyc();
}
$('.yksp-sidebar button').on('click',function(){panel($(this).data('panel'));});$('[data-goto]').on('click',function(){panel($(this).data('goto'));});
function products(){
 post('yksp_product_list').done(r=>{let a=r.data?.products||[];$('#yksp-stat-products').text(a.length);$('#yksp-stat-live').text(a.filter(x=>x.status==='publish').length);$('#yksp-stat-pending').text(a.filter(x=>x.status==='pending').length);
 if(!a.length){$('#yksp-products-table').html('<div class="yksp-empty">No products yet.</div>');return;}
 $('#yksp-products-table').html('<table><thead><tr><th>Product</th><th>SKU</th><th>Category</th><th>Price</th><th>Stock</th><th>Status</th><th>Action</th></tr></thead><tbody>'+
 a.map(p=>'<tr><td>'+esc(p.name)+'</td><td>'+esc(p.sku)+'</td><td>'+esc(p.category)+'</td><td>₹'+esc(p.price)+'</td><td>'+esc(p.stock??0)+'</td><td><span class="yksp-pill '+esc(p.status)+'">'+esc(p.status)+'</span></td><td><button class="yksp-mini edit-product" data-id="'+p.id+'">Edit</button> <button class="yksp-mini delete-product" data-id="'+p.id+'">Delete</button></td></tr>').join('')+'</tbody></table>');
 $('.edit-product').on('click',function(){let id=$(this).data('id');post('yksp_product_get',{product_id:id}).done(x=>{let p=x.data.product,f=$('#yksp-product-form');f[0].reset();$('#yksp-product-id').val(p.id);f.find('[name=name]').val(p.name);f.find('[name=category]').val(p.category);f.find('[name=sku]').val(p.sku);f.find('[name=price]').val(p.price);f.find('[name=mrp]').val(p.mrp);f.find('[name=stock]').val(p.stock??0);f.find('[name=brand]').val(p.brand);f.find('[name=description]').val(p.description);$('#yksp-product-heading').text('Edit Product');panel('add-product');});});
 $('.delete-product').on('click',function(){if(!confirm('Delete this product permanently?'))return;post('yksp_product_delete',{product_id:$(this).data('id')}).done(x=>{alert(x.data?.message||'Deleted');products();});});
 });
}
function orders(){
 post('yksp_orders').done(r=>{let a=r.data?.orders||[];$('#yksp-orders-table').html(a.length?'<table><thead><tr><th>Order</th><th>Date</th><th>Customer</th><th>Items</th><th>Amount</th><th>Payment</th><th>Status</th><th>Ship To</th></tr></thead><tbody>'+
 a.map(o=>'<tr><td>#'+o.id+'</td><td>'+esc(o.date)+'</td><td>'+esc(o.customer)+'</td><td>'+o.items.map(i=>esc(i.name)+' × '+esc(i.qty)).join('<br>')+'</td><td>'+o.amount+'</td><td>'+esc(o.payment)+'</td><td>'+esc(o.status)+'</td><td>'+esc(o.shipping)+'</td></tr>').join('')+'</tbody></table>':'<div class="yksp-empty">No seller orders yet.</div>');});
}
function returns(){
 post('yksp_returns').done(r=>{let a=r.data?.returns||[];$('#yksp-returns-table').html(a.length?'<table><thead><tr><th>Refund</th><th>Order</th><th>Date</th><th>Amount</th><th>Status</th><th>Update</th></tr></thead><tbody>'+
 a.map(x=>'<tr><td>#'+x.refund_id+'</td><td>#'+x.order_id+'</td><td>'+esc(x.date)+'</td><td>'+x.amount+'</td><td>'+esc(x.status)+'</td><td><select class="yksp-return-action" data-id="'+x.refund_id+'"><option value="">Select</option><option value="received">Received</option><option value="inspected">Inspected</option><option value="approved">Approved</option><option value="rejected">Rejected</option></select></td></tr>').join('')+'</tbody></table>':'<div class="yksp-empty">No refund/return records found for your products.</div>');
 $('.yksp-return-action').on('change',function(){let v=$(this).val();if(!v)return;post('yksp_return_action',{refund_id:$(this).data('id'),status:v}).done(()=>returns());});
 });
}
function settlements(){
 post('yksp_settlements').done(r=>{let a=r.data?.settlements||[],s=r.data?.summary||{};$('#yksp-sum-gross').text('₹'+(s.gross||0));$('#yksp-sum-commission').text('₹'+(s.commission||0));$('#yksp-sum-seller').text('₹'+(s.seller||0));$('#yksp-sum-pending').text('₹'+(s.pending||0));
 $('#yksp-settlements-table').html(a.length?'<table><thead><tr><th>Order</th><th>Gross</th><th>Commission</th><th>Seller Amount</th><th>Status</th><th>Created</th></tr></thead><tbody>'+a.map(x=>'<tr><td>#'+x.order_id+'</td><td>₹'+x.gross_amount+'</td><td>₹'+x.commission_amount+'</td><td>₹'+x.seller_amount+'</td><td>'+esc(x.status)+'</td><td>'+esc(x.created_at)+'</td></tr>').join('')+'</tbody></table>':'<div class="yksp-empty">No settlement records yet.</div>');
 });
}
function kyc(){
 post('yksp_kyc_status').done(r=>{let d=r.data?.documents||{};Object.keys(d).forEach(k=>$('#yksp-kyc-state-'+k).text(d[k].uploaded?(d[k].status||'submitted'):'Missing'));});
}
$('#yksp-kyc-form').on('submit',function(e){});
$(document).on('submit','.yksp-kyc-form',function(e){e.preventDefault();let f=this,m=$(this).closest('.yksp-kyc-item');formPost('yksp_kyc_upload',f).done(r=>{alert(r.data?.message||'Uploaded');kyc();}).fail(x=>alert(x.responseJSON?.data?.message||'Upload failed.'));});
$('#yksp-product-form').on('submit',function(e){e.preventDefault();let f=this,m=$(f).find('.yksp-message');m.text('Saving product…');formPost('yksp_product_save',f).done(r=>{m.text(r.data?.message||'Saved');if(r.success){f.reset();$('#yksp-product-id').val('');$('#yksp-product-heading').text('Add Product');panel('products');}}).fail(x=>m.text(x.responseJSON?.data?.message||'Could not save product.'));});
$('#yksp-product-clear').on('click',function(){$('#yksp-product-form')[0].reset();$('#yksp-product-id').val('');$('#yksp-product-heading').text('Add Product');});
$('#yksp-profile-form').on('submit',function(e){e.preventDefault();let f=this,m=$(f).find('.yksp-message');formPost('yksp_update_profile',f).done(r=>m.text(r.data?.message||'Saved'));});
$('#yksp-logout').on('click',function(){post('yksp_logout').done(()=>location.reload());});
if($('#yksp-panel-overview').length){products();kyc();}
});