<?php
if(!defined('ABSPATH')) exit;
class YKSP_Install{
 public static function activate(){
  if(!get_role('yk_seller')) add_role('yk_seller','Marketplace Vendor',array('read'=>true,'upload_files'=>true));
  add_option('yksp_commission_rate',10);
  global $wpdb;
  $c=$wpdb->get_charset_collate();
  $t=$wpdb->prefix.'yksp_settlements';
  $sql="CREATE TABLE $t(
   id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
   seller_id BIGINT UNSIGNED NOT NULL,
   order_id BIGINT UNSIGNED NOT NULL,
   gross_amount DECIMAL(18,2) NOT NULL DEFAULT 0,
   commission_amount DECIMAL(18,2) NOT NULL DEFAULT 0,
   seller_amount DECIMAL(18,2) NOT NULL DEFAULT 0,
   status VARCHAR(30) NOT NULL DEFAULT 'pending',
   created_at DATETIME NOT NULL,
   paid_at DATETIME NULL,
   PRIMARY KEY(id), KEY seller_id(seller_id), KEY order_id(order_id),
   UNIQUE KEY seller_order(seller_id,order_id)
  ) $c;";
  require_once ABSPATH.'wp-admin/includes/upgrade.php';
  dbDelta($sql);
  YKSP_Auth::migrate_legacy_seller_statuses();
  update_option('yksp_version',YKSP_VERSION);
 }
}
