<?php
/**
 * Plugin Name: Publicity Expert Marketplace Vendor Manager
 * Description: Free multivendor marketplace management for WooCommerce, including seller approval, products, orders, returns, commissions and settlements.
 * Version: 3.1.15
 * Author: PUBLICITY EXPERT
Author URI: https://publicityexpert.in/
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Text Domain: publicity-expert-marketplace-vendor-manager
 * Requires at least: 6.2
 * Requires PHP: 7.4
 * Requires Plugins: woocommerce
 */
if(!defined('ABSPATH')) exit;
define('YKSP_VERSION','3.1.15');
define('YKSP_DIR',plugin_dir_path(__FILE__));
define('YKSP_URL',plugin_dir_url(__FILE__));

foreach(array(
 'class-yksp-install.php','class-yksp-auth.php','class-yksp-kyc.php',
 'class-yksp-products.php','class-yksp-orders.php','class-yksp-returns.php',
 'class-yksp-settlements.php','class-yksp-admin.php','class-yksp-rest.php',
 'class-yksp-shortcode.php'
) as $yksp_file) require_once YKSP_DIR.'includes/'.$yksp_file;

register_activation_hook(__FILE__,array('YKSP_Install','activate'));

add_action('plugins_loaded',function(){
 if(class_exists('YKSP_Auth')) YKSP_Auth::migrate_legacy_seller_statuses();
},1);

add_action('plugins_loaded',function(){
 if(!class_exists('WooCommerce')){
  add_action('admin_notices',function(){
   echo '<div class="notice notice-error"><p><strong>Publicity Expert Marketplace Vendor Manager</strong> requires WooCommerce.</p></div>';
  });
  return;
 }
 YKSP_Auth::init();
 YKSP_KYC::init();
 YKSP_Products::init();
 YKSP_Orders::init();
 YKSP_Returns::init();
 YKSP_Settlements::init();
 YKSP_Admin::init();
 YKSP_REST::init();
 YKSP_Shortcode::init();
 add_action('admin_post_nopriv_yksp_register_fallback',array('YKSP_Auth','register_fallback'));
 add_action('admin_post_yksp_register_fallback',array('YKSP_Auth','register_fallback'));
});

add_action('wp_enqueue_scripts',function(){
 wp_enqueue_style('yksp',YKSP_URL.'assets/css/seller-portal.css',array(),YKSP_VERSION);
 wp_enqueue_script('yksp',YKSP_URL.'assets/js/seller-portal.js',array('jquery'),YKSP_VERSION,true);
 wp_localize_script('yksp','YKSP',array(
  'ajaxUrl'=>admin_url('admin-ajax.php'),
  'restUrl'=>esc_url_raw(rest_url('publicity-expert-marketplace-vendor-manager/v1/')),
  'nonce'=>wp_create_nonce('yksp_nonce'),
  'currency'=>function_exists('get_woocommerce_currency_symbol')?get_woocommerce_currency_symbol():'₹',
  'maxUpload'=>wp_max_upload_size(),
  'fallbackRegisterUrl'=>admin_url('admin-post.php')
 ));
});
